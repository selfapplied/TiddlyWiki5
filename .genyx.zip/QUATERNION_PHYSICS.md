# Eonyx Virtual Machine: Quaternion Physics Specification

This document outlines the physical model for the Eonyx Virtual Machine (VM). The VM is conceptualized as a thermodynamic computer where all state and operations are grounded in quaternion mathematics.

## 1. The Quaternion Register

The fundamental state of any token (an "atom" or "molecule") in the VM is represented by a unit-length quaternion, `q = w + xi + yj + zk`. These components are assigned a specific physical interpretation:

`q = (energy, symmetry, entropy, drift)`

-   **Energy (w):** The real component, representing the **Information Density** of the token. It is a measure of the token's internal complexity and information content.
-   **Symmetry (x):** The `i` component, representing the **Structural Invariance** of the token. It measures internal predictability, repetition, and compressibility.
-   **Entropy (y):** The `j` component, representing the **Binding Potential.** This is the token's capacity to form relationships and absorb new information. It is its interactive "charge."
-   **Drift (z):** The `k` component, representing the **Acquired Momentum.** This value is accumulated through interactions and represents the token's trajectory through the semantic space.

All state quaternions are normalized to unit length (`||q|| = 1`), meaning every "particle" in the VM exists on the surface of a 4D hypersphere.

## 2. Initialization Principle (Physical Signature)

An atomic token's initial quaternion is measured from its structure.

-   **Energy (w):** Calculated from the token's normalized Shannon entropy. Higher information content yields higher initial energy.
-   **Symmetry (x):** Calculated from the token's compressibility (e.g., using zlib). Higher compressibility means greater symmetry.
-   **Entropy (y):** Initialized to a small, constant positive value. This provides the initial "charge" for interaction.
-   **Drift (z):** Initialized to zero for all atomic tokens. Drift is only acquired through interaction.

The resulting quaternion is then normalized.

## 3. Dynamic Law (State Modulation)

The quaternion components of the VM's current state directly modulate the calculation of surprise (`delta`) within each simulation step. The `surprise_potential` is modulated as follows:

`modulated_potential = base_potential * (Energy + Symmetry) / (1 + Entropy) + Drift`

-   **Energy & Symmetry** amplify the system's sensitivity. A state with high information and structure is more "surprised" by perturbations.
-   **Entropy** dampens sensitivity. A state with high binding potential can more easily absorb new information.
-   **Drift** provides momentum, biasing the system's sensitivity based on recent history.

## 4. Fusion Equation (Binding Energy)

The fusion of two tokens (`q_A` and `q_B`) into a new molecule (`q_molecule`) is governed by quaternion multiplication: `q_molecule = q_A * q_B`. The physical interpretation of this operation reveals the concept of **Binding Energy**.

The energy of the new molecule is given by:

`w_molecule = (w_A * w_B) - (x_A * x_B + y_A * y_B + z_A * z_B)`

This can be read as:

`New Energy = (Product of Parent Energies) - Binding Energy`

The **Binding Energy** is the dot product of the parents' `(symmetry, entropy, drift)` vectors. It represents the energy released or consumed by the formation of a new structural relationship. The other components of the new molecule are lawfully derived from the cross-product interactions during the multiplication.

The final `q_molecule` is renormalized, conserving the system's state on the unit hypersphere.
